//
//  ViewController.swift
//  DiscountAppMVC
//
//  Created by Panuganti,Sirisha on 10/31/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var amountOL: UITextField!
    
    
    @IBOutlet weak var discountRate: UITextField!
    var priceAfterDiscount = 0.0;
    var imageName = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    
    @IBAction func calculateDiscount(_ sender: Any) {
        
        var amount  = Double(amountOL.text!) ?? 0.0
        var discount  = Double(discountRate.text!) ?? 0.0
       
        
        
         priceAfterDiscount = amount - (amount * discount/100)
        if(discount > 0.0){
            imageName = "Discount"
        }else{
            imageName = "noDiscount"
        }

    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var transition = segue.identifier
        if transition == "resultSegue"{
            var destination = segue.destination as! ResultViewController
            destination.amount = amountOL.text!
            destination.discount = discountRate.text!
            destination.priceAfterDisc = priceAfterDiscount
            destination.image = imageName
        }
    }
}

