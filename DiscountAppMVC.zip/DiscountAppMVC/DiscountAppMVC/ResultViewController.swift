//
//  ResultViewController.swift
//  DiscountAppMVC
//
//  Created by Panuganti,Sirisha on 10/31/23.
//

import UIKit

class ResultViewController: UIViewController {

    @IBOutlet weak var displayAmountOL: UILabel!
    @IBOutlet var displayDiscRateOL: UILabel!
    
    @IBOutlet weak var displayPriceAfterDiscOL: UILabel!
    
    @IBOutlet weak var imageOL: UIImageView!
    
    var amount = ""
    var discount = ""
    var priceAfterDisc = 0.0
    var image = ""
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        displayAmountOL.text! += amount
        displayDiscRateOL.text! += discount
        displayPriceAfterDiscOL.text! += String(priceAfterDisc)
        
        imageOL.image = UIImage(named: image)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
